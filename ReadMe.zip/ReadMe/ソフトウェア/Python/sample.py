import subprocess
import os
import sys

# スクリプトのあるフォルダをカレントディレクトリに設定
script_dir = os.path.dirname(os.path.abspath(sys.argv[0]))
os.chdir(script_dir)


# LuaLaTeX の絶対パス（手動で設定が必要な場合あり）
lualatex_path = "lualatex.exe"  # 例: r"C:\texlive\bin\win32\lualatex.exe"


# TeXファイルの絶対パスを取得
tex_file = "../TeXLive/sample/sample.tex"


# 出力ファイル名（拡張子なしで指定）
output_pdf = "output"

# LuaLaTeX のオプション設定（共通）
lualatex_cmd = [
    lualatex_path,
    "-interaction=batchmode",  # ログを最小限に抑える
    "-halt-on-error",          # エラー発生時に即停止
    "-file-line-error",        # エラーメッセージにファイル名と行番号を含める
    f"-jobname={output_pdf}.pdf",   # 出力ファイル名を指定
    "-output-directory=.",     # 出力フォルダ（カレントディレクトリ）
    tex_file
]

# env = os.environ.copy()
# env["PATH"] = os.pathsep.join([os.path.dirname(lualatex_path), env["PATH"]])  # lualatex.exe のフォルダを PATH に追加


# LuaLaTeX を2回実行
try:
    print("1回目のコンパイル...")
    subprocess.run(lualatex_cmd, check=True)

    print("2回目のコンパイル...")
    subprocess.run(lualatex_cmd, check=True)

    print(f"PDF 生成成功: {output_pdf}.pdf")

except subprocess.CalledProcessError:
    print("エラーが発生しました。")

# ウィンドウがすぐ閉じないようにする
input("終了するには Enter キーを押してください...")
